import bpy
import pymupdf
import bmesh
#a

def extractLinesFromPdf(soubor):
    doc = pymupdf.open(soubor)
    points = []
    
    for page in doc:
        text = page.get_text()
        print('NOVA STRANKA')
        #image_list = page.get_images()
        #print(image_list)
        paths = page.get_drawings()
        #print(paths[0].keys())
        
        #print(len(paths))
        counter = 0
        for path in paths:
            #print(path)
            #return
            listItems = path.get('items')
            width = path.get('width') 
            if width == 0.0:
                continue
            for item in listItems:
                for prvek in item:
                    if type(prvek) == pymupdf.Point:
                        vector = (prvek[1],prvek[0],0.0)
                        points.append(vector)
            points.append(0)        
            #print(points)
            
            '''
            bpy.ops.mesh.primitive_plane_add()
            objectMesh = bpy.context.active_object.data
            bFA=bmesh.new()
            counter = 0
            for vector in points:
                bFA.verts.new(vector)
                if counter % 2 == 1:
                    bFA.verts.ensure_lookup_table()
                    bFA.edges.new([bFA.verts[counter-1],bFA.verts[counter]])
                counter = counter + 1
            bFA.verts.ensure_lookup_table()
            
            bFA.to_mesh(objectMesh)
            bFA.free()
            '''
            counter = counter + 1
            #print(counter)
            #return

        #print(len(points))
        #print(points)
        #return

        bpy.ops.mesh.primitive_plane_add()
        objectMesh = bpy.context.active_object.data
        bFA=bmesh.new()
        counter = 0
        evenCheck = 0

        for vector in points:
            if vector == 0:
                continue
            bFA.verts.new(vector)

        bFA.verts.ensure_lookup_table()

        for vector in points:    
            if vector == 0:
                #counter = counter + 1
                evenCheck = 0
                #break
                continue
            if evenCheck % 2 == 1:
                bFA.edges.new([bFA.verts[counter-1],bFA.verts[counter]])
            counter = counter + 1
            evenCheck = evenCheck + 1
            #print(counter)

        bFA.verts.ensure_lookup_table()
        
        bFA.to_mesh(objectMesh)
        bFA.free()    


'''
    for page_num, page in enumerate(doc):
        shapes = page.get_drawings()  # Získání vektorových objektů
        for shape in shapes:
            for item in shape["items"]:
                if item[0] == "l":  # "l" znamená úsečka (line)
                    points = item[1]  # Souřadnice čáry

                    # Ověříme, že máme správný počet bodů
                    if len(points) == 4:
                        x0, y0, x1, y1 = points  # Správná extrakce bodů
                        lines.append(((x0, y0), (x1, y1)))
                    else:
                        print(f"Varování: Neočekávaný formát čáry na stránce {page_num + 1}: {points}")

    return lines
'''
# Použití
soubor = "vykres.pdf"
lines = extractLinesFromPdf(soubor)

